import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-hotel-room-add',
  templateUrl: './hotelowner-hotel-room-add.component.html',
  styleUrls: ['./hotelowner-hotel-room-add.component.css']
})
export class HotelownerHotelRoomAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
