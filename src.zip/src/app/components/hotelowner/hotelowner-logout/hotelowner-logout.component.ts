import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-logout',
  templateUrl: './hotelowner-logout.component.html',
  styleUrls: ['./hotelowner-logout.component.css']
})
export class HotelownerLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
