import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-dashboard',
  templateUrl: './hotelowner-dashboard.component.html',
  styleUrls: ['./hotelowner-dashboard.component.css']
})
export class HotelownerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
