import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-login',
  templateUrl: './hotelowner-login.component.html',
  styleUrls: ['./hotelowner-login.component.css']
})
export class HotelownerLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
