import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelowner-hotel-list',
  templateUrl: './hotelowner-hotel-list.component.html',
  styleUrls: ['./hotelowner-hotel-list.component.css']
})
export class HotelownerHotelListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
