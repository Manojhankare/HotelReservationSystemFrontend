import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HotelService {

  private baseUrl = 'http://localhost:8990';

  constructor(private http: HttpClient) { }

  addHotel(hotelData: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/hotels/savehotel`, hotelData);
  }

  // Other methods...

  getCities(): Observable<string[]> {
    return this.http.get<string[]>(`${this.baseUrl}/cities`);
  }
}
