import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HotelService } from 'src/app/services/hotel.service';
import { Routes } from '@angular/router';

@Component({
  selector: 'app-add-hotels',
  templateUrl: './add-hotels.component.html',
  styleUrls: ['./add-hotels.component.css']
})
export class AddHotelsComponent implements OnInit {

  hotelForm: FormGroup;

  constructor(private fb: FormBuilder, private hotelService: HotelService) {
    this.hotelForm = this.fb.group({
      hname: ['', Validators.required],
      hemail: ['', [Validators.required, Validators.email]],
      hno: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      hadd: ['', Validators.required],
      hcity: ['', Validators.required],
      hServices: this.fb.array([]), 
      hImgUrl: ['']
    });
  }

  ngOnInit(): void {
    // Any initialization logic can go here
  }

  onSubmit() {
    if (this.hotelForm.valid) {
      const hotelData = this.hotelForm.value;
      this.hotelService.addHotel(hotelData).subscribe(response => {
        console.log('Hotel added successfully!', response);
        // Add any additional logic you need after successful hotel addition
      }, error => {
        console.error('Error adding hotel:', error);
        // Handle errors as needed
      });
    } else {
      console.log('Form is invalid. Please check the fields.');
    }
  }
}
