import { HotelOwner } from './hotel-owner';

describe('HotelOwner', () => {
  it('should create an instance', () => {
    expect(new HotelOwner()).toBeTruthy();
  });
});
