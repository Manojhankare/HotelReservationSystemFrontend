export class HotelOwner {
}
