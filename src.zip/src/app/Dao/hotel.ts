export class Hotel {
}
